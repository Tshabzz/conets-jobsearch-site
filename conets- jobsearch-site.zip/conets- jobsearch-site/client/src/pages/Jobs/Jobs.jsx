
import { useState } from 'react';
import './style/jobs.css'
import SearchTwoToneIcon from '@mui/icons-material/SearchTwoTone';

const JobsPage = () => {
    const [numberOfJobsMatched,] = useState(5672)

    return (
        <div className='jp'>
            <div className="jp__search">
                <div>
                    <div><SearchTwoToneIcon /></div>
                    <div> <input type="text" name="jobs_available" placeholder={numberOfJobsMatched + 'jobs matched.'} /> </div>
                </div>
            </div>
        </div>
    )
}

export default JobsPage