

const EventsPage = () => {

    return (
        <div>Events Page</div>
    )
}

export default EventsPage