

const ApplicationsPage = () => {

    return (
        <div>Events Page</div>
    )
}

export default ApplicationsPage