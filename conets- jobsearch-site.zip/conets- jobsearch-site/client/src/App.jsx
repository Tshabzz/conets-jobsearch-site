import logo from './images/logo.svg';
import './App.css';
import { useState } from 'react';
import MailOutlineIcon from '@mui/icons-material/MailOutlineTwoTone';
import { Avatar } from '@mui/material';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import HomePage from './pages/Home/Home'
import JobsPage from './pages/Jobs/Jobs'


function App() {
  const [pages, setPage] = useState(['Work Portfolio', 'Jobs', 'Applications', 'Network', 'Events', ])
  const [activePage, setActivePage] = useState('Work Portfolio')
  const [profile, setProfile] = useState({
    imageUri: '',
    displayName: ''
  })

  return (
    <BrowserRouter>
      <div className="App">
        <div className="tb">
          <div className='tb__icn'>
            <img src={logo} alt="My Conets" />
            <h3>My Conets</h3>
          </div>
          <div className="tb__elements tb__element__active">
              {pages.map((page, index) => (
                <h3 key={index} >{page}</h3>
              ))}
          </div>
          <div className="tb__avatar">
              <div className="tb__avatar__mt"><MailOutlineIcon sx={{color: 'rgb(129, 130, 130)'}} /></div>
                <div className="dropdown">
                  <div className='mt__avatar'><Avatar /></div>
                  <div className="dropdown-content">
                    <a href="#">Account</a>
                    <a href="#">Profile</a>
                    <a href="#">Notification</a>
                    <a href="#">Sign Out</a>
                  </div>
                </div>
          </div>
        </div>
        <div className="body">
          <Routes>
            <Route path='/' index element={<HomePage />} />
            <Route path="jobs" element={<JobsPage />}/>
          </Routes>
        </div>
      </div>
    </BrowserRouter>
  );
}

export default App;
